var express =require('express');
var app = express();

var http = require('http');
var server = http.Server(app);
var io = require('socket.io')(server);

app.use("/public", express.static(__dirname + '/public'));
app.set('view engine', 'pug');
app.set('views', __dirname + '/views');

app.get('/', (req,res) => { res.render('vote')})
app.get('/result', (req,res) => {res.render('result')})
app.get('*', (req,res) => {res.render('404')} )


io.on("connection", (socket) => {
    console.log('a user connected')
socket.on("disconnect", () => {
    console.log('Now disconnected.')
})
    socket.on('payload', (obj) => {
        console.log('socket obj', obj)
        io.emit('payload back', obj)
    })
})

server.listen(3000, () => {
    console.log('Server is up and running!');
})