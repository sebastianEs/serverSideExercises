$(function () {
var socket = io();
var number = document.getElementById('amount');
  $('form').submit(function () {
      var payload = {
          Parti: $('#selectParty').val(),
          Vallokal: $('#selectChurch').val(),
          Röster: $('#amount').val()
      }
      
      if(number === "" ) {
          alert('Please enter a number')
          return null;
      } else {
          socket.emit('payload', payload);
      }
      
      
      })
    socket.on('payload back', (obj) => {
        let text =""
        let title="";
        for( let x in obj ) {
            if( obj.hasOwnProperty(x) ) {
                title += x + " " + ": "
                text += obj[x] + " " + "\n";
            }
            console.log(`inside for obj.${x} = ${obj[x]}`);
            
        }
                
               console.log('object ', text)
                $('#votes').append($('<h2>').text(title)); 
                $('#votes').append($('<li>').text(text)); 
 
    })
    
    return false;
  });
  
